package online.hrycesky.nikketoolkit;

import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Streaming scanner for likely localization markers inside one CDB entry. */
public final class LocalizationScanner {
    private static final int BUFFER_SIZE = 256 * 1024;
    private static final int CONTEXT_RADIUS = 384;

    private static final String[] TERMS = {
            "Locale_", "Localization", "Message", "TextAsset"
    };

    public static final class Result {
        public final LinkedHashSet<String> terms = new LinkedHashSet<>();
        public long firstMatchRelativeOffset = -1;
        public String preview = "";
        public String encoding = "";

        public boolean found() { return !terms.isEmpty(); }
    }

    public static Result scan(FileChannel ch, long entryOffset, long entrySize) throws IOException {
        Result result = new Result();
        if (entrySize <= 0) return result;

        List<PatternDef> patterns = new ArrayList<>();
        int maxPattern = 1;
        for (String term : TERMS) {
            byte[] ascii = term.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.US_ASCII);
            byte[] utf16 = term.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.UTF_16LE);
            patterns.add(new PatternDef(term, "ASCII", ascii, false));
            patterns.add(new PatternDef(term, "UTF-16LE", utf16, true));
            maxPattern = Math.max(maxPattern, Math.max(ascii.length, utf16.length));
        }

        int overlap = maxPattern - 1;
        byte[] carry = new byte[overlap];
        int carryLen = 0;
        ByteBuffer buf = ByteBuffer.allocate(BUFFER_SIZE);
        long pos = 0;

        while (pos < entrySize) {
            buf.clear();
            int want = (int)Math.min((long)buf.capacity(), entrySize - pos);
            buf.limit(want);
            int got = readAtMost(ch, buf, entryOffset + pos);
            if (got <= 0) break;

            byte[] window = new byte[carryLen + got];
            if (carryLen > 0) System.arraycopy(carry, 0, window, 0, carryLen);
            buf.flip();
            buf.get(window, carryLen, got);

            long windowBase = pos - carryLen;
            for (PatternDef pd : patterns) {
                int from = 0;
                while (from <= window.length - pd.pattern.length) {
                    int idx = indexOfIgnoreAsciiCase(window, pd.pattern, from, pd.utf16);
                    if (idx < 0) break;
                    result.terms.add(pd.term);
                    long rel = windowBase + idx;
                    if (result.firstMatchRelativeOffset < 0 || rel < result.firstMatchRelativeOffset) {
                        result.firstMatchRelativeOffset = rel;
                        result.encoding = pd.encoding;
                    }
                    from = idx + Math.max(1, pd.pattern.length);
                }
            }

            if (result.found() && result.preview.isEmpty()) {
                result.preview = makePreview(ch, entryOffset, entrySize, result.firstMatchRelativeOffset);
            }

            carryLen = Math.min(overlap, window.length);
            if (carryLen > 0) System.arraycopy(window, window.length - carryLen, carry, 0, carryLen);
            pos += got;
        }
        return result;
    }

    private static int readAtMost(FileChannel ch, ByteBuffer b, long absolutePos) throws IOException {
        int total = 0;
        while (b.hasRemaining()) {
            int r = ch.read(b, absolutePos + total);
            if (r < 0) break;
            if (r == 0) break;
            total += r;
        }
        return total;
    }

    private static int indexOfIgnoreAsciiCase(byte[] data, byte[] pattern, int from, boolean utf16) {
        outer:
        for (int i = Math.max(0, from); i <= data.length - pattern.length; i++) {
            if (utf16 && (i & 1) != 0) continue;
            for (int j = 0; j < pattern.length; j++) {
                int a = data[i + j] & 0xff;
                int p = pattern[j] & 0xff;
                if (utf16 && (j & 1) == 1) {
                    if (a != p) continue outer;
                } else {
                    a = lowerAscii(a);
                    p = lowerAscii(p);
                    if (a != p) continue outer;
                }
            }
            return i;
        }
        return -1;
    }

    private static int lowerAscii(int c) {
        if (c >= 'A' && c <= 'Z') return c + 32;
        return c;
    }

    private static String makePreview(FileChannel ch, long entryOffset, long entrySize, long matchRel) throws IOException {
        long start = Math.max(0, matchRel - CONTEXT_RADIUS);
        long end = Math.min(entrySize, matchRel + CONTEXT_RADIUS);
        int len = (int)Math.min(2L * CONTEXT_RADIUS, end - start);
        if (len <= 0) return "";
        ByteBuffer b = ByteBuffer.allocate(len);
        int got = readAtMost(ch, b, entryOffset + start);
        byte[] bytes = new byte[got];
        b.flip(); b.get(bytes);

        String ascii = sanitizeAscii(bytes);
        String utf16 = sanitizeUtf16(bytes);
        String best = utf16.length() > ascii.length() * 1.15 ? utf16 : ascii;
        if (best.length() > 700) best = best.substring(0, 700);
        return best;
    }

    private static String sanitizeAscii(byte[] b) {
        StringBuilder sb = new StringBuilder();
        int run = 0;
        for (byte value : b) {
            int v = value & 0xff;
            if (v == 9 || v == 10 || v == 13 || (v >= 32 && v <= 126)) {
                char c = (v == 9 || v == 10 || v == 13) ? ' ' : (char)v;
                sb.append(c); run++;
            } else {
                if (run >= 4) sb.append(' ');
                run = 0;
            }
        }
        return collapseSpaces(sb.toString());
    }

    private static String sanitizeUtf16(byte[] b) {
        int even = b.length - (b.length % 2);
        if (even <= 0) return "";
        String s = new String(b, 0, even, StandardCharsets.UTF_16LE);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLetterOrDigit(c) || Character.isWhitespace(c) || "_./\\:-[](){}'\"=,;!?@#$%&+*".indexOf(c) >= 0) sb.append(c);
            else sb.append(' ');
        }
        return collapseSpaces(sb.toString());
    }

    private static String collapseSpaces(String s) {
        return s.replaceAll("\\s+", " ").trim();
    }

    private static final class PatternDef {
        final String term, encoding;
        final byte[] pattern;
        final boolean utf16;
        PatternDef(String term, String encoding, byte[] pattern, boolean utf16) {
            this.term = term; this.encoding = encoding; this.pattern = pattern; this.utf16 = utf16;
        }
    }
}
