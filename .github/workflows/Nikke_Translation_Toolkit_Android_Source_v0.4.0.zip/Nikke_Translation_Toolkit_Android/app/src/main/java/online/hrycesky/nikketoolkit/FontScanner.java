package online.hrycesky.nikketoolkit;

import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Finds font-related Unity strings and embedded standalone font containers. */
public final class FontScanner {
    private static final int BUFFER_SIZE = 256 * 1024;
    private static final int CONTEXT_RADIUS = 256;
    private static final String[] TERMS = {
            "TMP_FontAsset", "FontAsset", "FontData", ".ttf", ".otf", ".woff", ".woff2"
    };

    public static final class EmbeddedFont {
        public long relativeOffset;
        public long length;
        public String type;
        EmbeddedFont(long relativeOffset, long length, String type) {
            this.relativeOffset = relativeOffset; this.length = length; this.type = type;
        }
    }

    public static final class Result {
        public final LinkedHashSet<String> terms = new LinkedHashSet<>();
        public final ArrayList<EmbeddedFont> embeddedFonts = new ArrayList<>();
        public long firstMatchRelativeOffset = -1;
        public String preview = "";
        public boolean found() { return !terms.isEmpty() || !embeddedFonts.isEmpty(); }
    }

    public static Result scan(FileChannel ch, long entryOffset, long entrySize) throws IOException {
        Result result = new Result();
        if (entrySize <= 0) return result;

        List<PatternDef> patterns = new ArrayList<>();
        int maxPattern = 4;
        for (String term : TERMS) {
            byte[] ascii = term.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.US_ASCII);
            byte[] utf16 = term.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.UTF_16LE);
            patterns.add(new PatternDef(term, ascii, false));
            patterns.add(new PatternDef(term, utf16, true));
            maxPattern = Math.max(maxPattern, Math.max(ascii.length, utf16.length));
        }

        int overlap = Math.max(32, maxPattern - 1);
        byte[] carry = new byte[overlap];
        int carryLen = 0;
        ByteBuffer buf = ByteBuffer.allocate(BUFFER_SIZE);
        long pos = 0;
        HashSet<Long> seenFontOffsets = new HashSet<>();

        while (pos < entrySize) {
            buf.clear();
            int want = (int)Math.min((long)buf.capacity(), entrySize - pos);
            buf.limit(want);
            int got = readAtMost(ch, buf, entryOffset + pos);
            if (got <= 0) break;

            byte[] window = new byte[carryLen + got];
            if (carryLen > 0) System.arraycopy(carry, 0, window, 0, carryLen);
            buf.flip(); buf.get(window, carryLen, got);
            long windowBase = pos - carryLen;

            for (PatternDef pd : patterns) {
                int from = 0;
                while (from <= window.length - pd.pattern.length) {
                    int idx = indexOfIgnoreAsciiCase(window, pd.pattern, from, pd.utf16);
                    if (idx < 0) break;
                    long rel = windowBase + idx;
                    result.terms.add(pd.term);
                    if (result.firstMatchRelativeOffset < 0 || rel < result.firstMatchRelativeOffset)
                        result.firstMatchRelativeOffset = rel;
                    from = idx + Math.max(1, pd.pattern.length);
                }
            }

            // Detect binary sfnt/OpenType/WOFF containers. Validate and calculate their real byte length.
            for (int i = 0; i <= window.length - 4; i++) {
                long rel = windowBase + i;
                if (rel < 0 || seenFontOffsets.contains(rel)) continue;
                String type = signatureType(window, i);
                if (type == null) continue;
                long length = measureFont(ch, entryOffset + rel, entryOffset + entrySize, type);
                if (length > 0 && rel + length <= entrySize) {
                    seenFontOffsets.add(rel);
                    result.embeddedFonts.add(new EmbeddedFont(rel, length, type));
                    if (result.firstMatchRelativeOffset < 0 || rel < result.firstMatchRelativeOffset)
                        result.firstMatchRelativeOffset = rel;
                }
            }

            carryLen = Math.min(overlap, window.length);
            if (carryLen > 0) System.arraycopy(window, window.length - carryLen, carry, 0, carryLen);
            pos += got;
        }

        if (result.found()) result.preview = makePreview(ch, entryOffset, entrySize, Math.max(0, result.firstMatchRelativeOffset));
        return result;
    }

    private static String signatureType(byte[] d, int i) {
        if (i + 4 > d.length) return null;
        int a=d[i]&255,b=d[i+1]&255,c=d[i+2]&255,e=d[i+3]&255;
        if (a==0 && b==1 && c==0 && e==0) return "TTF";
        if (a=='O' && b=='T' && c=='T' && e=='O') return "OTF";
        if (a=='w' && b=='O' && c=='F' && e=='F') return "WOFF";
        if (a=='w' && b=='O' && c=='F' && e=='2') return "WOFF2";
        if (a=='t' && b=='t' && c=='c' && e=='f') return "TTC";
        return null;
    }

    private static long measureFont(FileChannel ch, long absoluteOffset, long entryEnd, String type) {
        try {
            if ("WOFF".equals(type) || "WOFF2".equals(type)) {
                byte[] h = read(ch, absoluteOffset, 12);
                long len = u32be(h, 8);
                return validLength(len, absoluteOffset, entryEnd) ? len : -1;
            }
            if ("TTF".equals(type) || "OTF".equals(type)) {
                byte[] h = read(ch, absoluteOffset, 12);
                int tables = u16be(h, 4);
                if (tables <= 0 || tables > 512) return -1;
                long dirLen = 12L + 16L * tables;
                if (absoluteOffset + dirLen > entryEnd || dirLen > 1024 * 1024) return -1;
                byte[] dir = read(ch, absoluteOffset + 12, tables * 16);
                long max = dirLen;
                for (int i=0;i<tables;i++) {
                    int p=i*16;
                    long off=u32be(dir,p+8), len=u32be(dir,p+12);
                    if (off > Integer.MAX_VALUE || len > Integer.MAX_VALUE) return -1;
                    max=Math.max(max, off+len);
                }
                return validLength(max, absoluteOffset, entryEnd) ? max : -1;
            }
            // TTC contains multiple fonts and is less safe to carve without walking every subfont.
            // Flag it as a candidate, but do not auto-extract a guessed range.
            if ("TTC".equals(type)) return -1;
        } catch (Exception ignored) {}
        return -1;
    }

    private static boolean validLength(long len,long off,long end){return len>=64 && len<=256L*1024*1024 && off+len<=end;}
    private static byte[] read(FileChannel ch,long off,int len)throws IOException{ByteBuffer b=ByteBuffer.allocate(len);int n=readAtMost(ch,b,off);if(n<len)throw new EOFException();return b.array();}
    private static int u16be(byte[] b,int p){return ((b[p]&255)<<8)|(b[p+1]&255);}
    private static long u32be(byte[] b,int p){return ((long)(b[p]&255)<<24)|((long)(b[p+1]&255)<<16)|((long)(b[p+2]&255)<<8)|(long)(b[p+3]&255);}

    private static int readAtMost(FileChannel ch, ByteBuffer b, long pos)throws IOException{int total=0;while(b.hasRemaining()){int r=ch.read(b,pos+total);if(r<=0)break;total+=r;}return total;}
    private static int indexOfIgnoreAsciiCase(byte[] data, byte[] pattern, int from, boolean utf16){outer:for(int i=Math.max(0,from);i<=data.length-pattern.length;i++){if(utf16&&(i&1)!=0)continue;for(int j=0;j<pattern.length;j++){int a=data[i+j]&255,p=pattern[j]&255;if(utf16&&(j&1)==1){if(a!=p)continue outer;}else{a=lower(a);p=lower(p);if(a!=p)continue outer;}}return i;}return -1;}
    private static int lower(int c){return c>='A'&&c<='Z'?c+32:c;}

    private static String makePreview(FileChannel ch,long entryOffset,long entrySize,long rel)throws IOException{
        long start=Math.max(0,rel-CONTEXT_RADIUS), end=Math.min(entrySize,rel+CONTEXT_RADIUS);
        int len=(int)(end-start); if(len<=0)return ""; ByteBuffer b=ByteBuffer.allocate(len);int got=readAtMost(ch,b,entryOffset+start);byte[] x=new byte[got];b.flip();b.get(x);
        StringBuilder s=new StringBuilder();for(byte q:x){int v=q&255;if(v==9||v==10||v==13||(v>=32&&v<=126))s.append(v<32?' ':(char)v);else s.append(' ');}return s.toString().replaceAll("\\s+"," ").trim();
    }

    private static final class PatternDef { final String term; final byte[] pattern; final boolean utf16; PatternDef(String t,byte[] p,boolean u){term=t;pattern=p;utf16=u;} }
}
