package online.hrycesky.nikketoolkit;

import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public final class NkabDecryptor {
    private static short plus100(short v){ return (short)(v+100); }

    public static byte[] decrypt(byte[] input) throws Exception {
        if(input.length < 48 || input[0]!='N'||input[1]!='K'||input[2]!='A'||input[3]!='B')
            throw new IOException("Není NKAB.");
        ByteBuffer b=ByteBuffer.wrap(input).order(ByteOrder.LITTLE_ENDIAN);
        b.position(4);
        int version=b.getInt();
        int headerSize=plus100(b.getShort()) & 0xffff;
        int encryptionMode=plus100(b.getShort()) & 0xffff;
        int keyLength=plus100(b.getShort()) & 0xffff;
        int encryptedLength=plus100(b.getShort()) & 0xffff;
        if(version!=1 || keyLength<=0 || keyLength>128 || encryptedLength<=0 || encryptedLength>input.length)
            throw new IOException("Neznámý NKAB formát.");
        byte[] key=new byte[keyLength]; b.get(key);
        byte[] iv=new byte[keyLength]; b.get(iv);
        if(iv.length!=16) throw new IOException("NKAB IV nemá 16 B.");
        int encPos=b.position();
        if(encPos+encryptedLength>input.length) throw new IOException("Poškozený NKAB.");
        byte[] encrypted=Arrays.copyOfRange(input,encPos,encPos+encryptedLength);
        byte[] hashed=MessageDigest.getInstance("SHA-256").digest(key);
        Cipher cipher=Cipher.getInstance("AES/CBC/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,new SecretKeySpec(hashed,"AES"),new IvParameterSpec(iv));
        byte[] first=cipher.doFinal(encrypted);
        byte[] out=new byte[first.length + input.length-(encPos+encryptedLength)];
        System.arraycopy(first,0,out,0,first.length);
        System.arraycopy(input,encPos+encryptedLength,out,first.length,input.length-(encPos+encryptedLength));
        return out;
    }
}
